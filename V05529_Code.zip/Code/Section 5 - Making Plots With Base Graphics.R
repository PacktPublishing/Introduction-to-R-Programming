# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Section 5 - Making Plots With Base Graphics
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ------------------------------------------------------------------------
plot(mtcars$wt, mtcars$mpg)

## ------------------------------------------------------------------------
abline(lm(mpg ~ wt, data=mtcars))

## ------------------------------------------------------------------------
plot(mtcars$wt, mtcars$mpg, main="Mpg vs Wt")

## ------------------------------------------------------------------------
plot(mtcars$wt, mtcars$mpg, main="Mpg vs Wt", xlab="Weight (1000 lbs)", ylab="Miles per gallon")

## ------------------------------------------------------------------------
plot(mtcars$wt, mtcars$mpg, main="Mpg vs Wt", xlab="Weight (1000 lbs)", ylab="Miles per gallon", pch=4)

## ------------------------------------------------------------------------
plot(mtcars$wt, mtcars$mpg, main="Mpg vs Wt", xlab="Weight (1000 lbs)", ylab="Miles per gallon", 
     pch=4, col="red")

## ------------------------------------------------------------------------
plot(mtcars$wt, mtcars$mpg, main="Mpg vs Wt", xlab="Weight (1000 lbs)", ylab="Miles per gallon", pch=4, col="red", col.main="blue", col.lab="brown", col.axis="orange")

## ------------------------------------------------------------------------
colors()

## ------------------------------------------------------------------------
plot(mtcars$wt, mtcars$mpg, main="Mpg vs Wt", xlab="Weight (1000 lbs)", ylab="Miles per gallon", pch=4, col="red", col.main="blue", col.lab="brown", col.axis="orange", cex=1.5, cex.axis=1.5, cex.lab=1.5)

## ------------------------------------------------------------------------
text(mtcars$wt, mtcars$mpg+1, labels=rownames(mtcars), cex=0.75)

## ------------------------------------------------------------------------
text(4.5, 30, labels="Car Makes", cex=2, col="red")

## ------------------------------------------------------------------------
mtext("Right side margin", side=4, cex=1.5, col="green4")

## ------------------------------------------------------------------------
legend("bottomright", inset=.01, title="mgp vs wt", legend=c("mgp vs wt"), fill="blue", horiz=TRUE) 
grid()

## ------------------------------------------------------------------------
png("myplot.png", height=300, width=300)
plot(mtcars$wt, mtcars$mpg, main="Mpg vs Wt", xlab="Weight (1000 lbs)", ylab="Miles per gallon", pch=4, col="red", col.main="blue", col.lab="brown", col.axis="orange", cex=1.5, cex.axis=1.5, cex.lab=1.5)
dev.off() # turn off device

## ------------------------------------------------------------------------
pdf("mypdfplot.pdf", height=6, width=6)
plot(mtcars$hp, mtcars$mpg, main="Mpg vs hp", xlab="HP", ylab="Miles per gallon", pch=4, col="red", col.main="blue", col.lab="brown", col.axis="orange", cex=1.5, cex.axis=1.5, cex.lab=1.5)
dev.off() # turn off device

## ------------------------------------------------------------------------
set.seed(1001)
year <- 1901:1920
population <- c(1:20)
gdp <- sample(40:50, 20, replace = T)

## ------------------------------------------------------------------------
plot.new()
par(mar=c(5, 4, 4, 5) + 0.1)
plot(year, population, type="b", ylim=c(0,21), lwd=2, main="Multiple Y axes", col="green3", pch=16)

## ------------------------------------------------------------------------
par(new=T)  
plot(year, gdp, type="b", axes=F, xlab="", ylab="", lwd=2, col="red", pch=15, ylim=c(30,60))
axis(4, ylim=c(30,60))  # draw second y axis.
mtext("gdp", side=4, line=3)
legend("bottomright", inset=0.05, col=c("green3","red"),lty=1,legend=c("pop","gdp"))

## ------------------------------------------------------------------------
par(mfrow=c(2, 2))
plot(mtcars$wt, mtcars$mpg, xlab="Car Weight", ylab="Miles Per Gallon", main="wt")
plot(mtcars$qsec, mtcars$mpg, xlab="Qsec", ylab="Miles Per Gallon", main="qsec")
plot(mtcars$hp, mtcars$mpg, xlab="Hp", ylab="Miles Per Gallon", main="hp")
plot(mtcars$disp, mtcars$mpg, xlab="Disp", ylab="Miles Per Gallon", main="disp")

## ------------------------------------------------------------------------
par(mfrow=c(1,1))
par(mar=c(4,4,4,1))
plot.new()  # draw and empty plot.

## ------------------------------------------------------------------------
par(fig=c(0, 0.8, 0.0, 0.8), new=TRUE, bg="wheat1")
plot(mtcars$wt, mtcars$mpg, xlab="Car Weight", ylab="Miles Per Gallon")

## ------------------------------------------------------------------------
par(fig=c(0,0.8,0.55,1), new=TRUE)

## ------------------------------------------------------------------------
boxplot(mtcars$wt, horizontal=TRUE, axes=FALSE)

## ------------------------------------------------------------------------
par(fig=c(0.65,1,0,0.8),new=TRUE)
boxplot(mtcars$mpg, axes=FALSE)
mtext("Enhanced Scatterplot", side=3, outer=TRUE, line=-3)

## ------------------------------------------------------------------------
hist(mtcars$mpg)

## ------------------------------------------------------------------------
brks <- seq(0, max(mtcars$mpg + 10), 5)
brks
hist(mtcars$mpg, breaks=brks)

## ------------------------------------------------------------------------
hist(mtcars$mpg, breaks=3)

## ------------------------------------------------------------------------
plot(density(mtcars$mpg))

## ------------------------------------------------------------------------
mpg_new <- cut(mtcars$mpg, breaks = c(0, 10, 15, 20, 25, 30, 35))
tbl <- table(mpg_new)
tbl

## ------------------------------------------------------------------------
barplot(tbl, main = "MPG")

## ------------------------------------------------------------------------
dotchart(mtcars$mpg,labels=row.names(mtcars), cex=.7, main="MPG", xlab="MPG")

## ------------------------------------------------------------------------
mpg <- mtcars$mpg[order(mtcars$mpg)]
car_names <- row.names(mtcars)[order(mtcars$mpg)]
cyl <- mtcars$cyl[order(mtcars$mpg)]

dotchart(mpg,labels=car_names, cex=.7, main="MPG", xlab="MPG", groups = cyl, color = cyl-2)

## ------------------------------------------------------------------------
boxplot(mtcars$wt)

## ------------------------------------------------------------------------
boxplot(mpg ~ cyl, data=mtcars)