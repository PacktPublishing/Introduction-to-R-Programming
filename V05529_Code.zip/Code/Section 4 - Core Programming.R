# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Section 4 - Core Programming
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ------------------------------------------------------------------------
# install.packages("lubridate", repos = "http://cran.rstudio.com")
library(lubridate)
Sys.time()
class(Sys.time())

## ------------------------------------------------------------------------
# -- paste these line --
d1 <- "2014-11-28"
d2 <- "2-19-11"
d3 <- "04 April 2016"
d4 <- "October 19th 2016"
d5 <- "2016-06-25 04:30:00"

## ------------------------------------------------------------------------
d1 <- ymd(d1, tz="UTC")
d2 <- mdy(d2, tz="UTC")
d3 <- dmy(d3, tz="UTC")
d4 <- mdy(d4, tz="UTC")
d5 <- ymd_hms(d5, tz="UTC")

## ------------------------------------------------------------------------
day(d1)  # the 28th day of month
month(d1)  # falls on the 11th month of the year.
months(d1)  # if you want month in character.
week(d1)  # falls on the 48th week
weekdays(d1)  # is a friday.
quarter(d1)  # falls on the 4th quarter
quarters(d1)

# If you wish to find out the number of days in the month of `d1`, use the Hmisc package.
library(Hmisc)
monthDays(d1)
# or to find the number of days in the year
library(Hmisc)
yearDays(d1)

## ------------------------------------------------------------------------
d <- d1 - d2
d
# That gives a text string, whose class is:
class(d) # difftime
# If you want just the number, do:
as.numeric(d)  # and you will get just the number.
# Using the difftime function, you can find the time difference in any time unit.
difftime(d1, d2, unit="sec") 
difftime(d1, d2, unit="week") 

## ------------------------------------------------------------------------
library(lubridate)
d1 <- "04/1981/20"
d1 <- myd(d1, tz="UTC")
weekdays(d1)  #  so that was a monday.
Hmisc::monthDays(d1)  # and the month had 30 days.

## ------------------------------------------------------------------------
paste("txt1", "txt2")
# By default, the strings will have a space between them. If you dont want that space, then explicitly set the 'sep' argument.
paste("txt1", "txt2", sep="")
# likewise you can set any character or word as separator.
paste("txt1", "txt2", "txt3", sep="------------")

## ------------------------------------------------------------------------
paste(c("a", "b"),  c("d", "e"), sep="")
# if you want further collapse them into a single string, then set the collapse argument
paste(c("a", "b"),  c("d", "e"), sep="", collapse="-")

## ------------------------------------------------------------------------
a <- "The lord of the rings and harry potter are the most fascinating tales ever told in English. 12.3."

b <- "@r_programming  "

## ------------------------------------------------------------------------
# Lets load up the stringr package
# install.packages("stringr", repos = "http://cran.rstudio.com")
library(stringr)
str_count(b)

## ------------------------------------------------------------------------
# To upper case
str_to_upper(a)
# To lower case
str_to_lower(a)
# to title case
str_to_title(a)

## ------------------------------------------------------------------------
str_split(a, " ")

## ------------------------------------------------------------------------
unlist(str_split(a, " "))

## ------------------------------------------------------------------------
substr(b, 2, 13)

## ------------------------------------------------------------------------
word(a, c(2:4))

## ------------------------------------------------------------------------
str_detect(b, "[:punct:]")

## ------------------------------------------------------------------------
str_detect(b, "@")

## ------------------------------------------------------------------------
str_replace_all(a, "t", "L")

## ------------------------------------------------------------------------
str_trim(b, side="both")

## ------------------------------------------------------------------------
str_replace_all(b, "[:punct:]", "")

## ------------------------------------------------------------------------
str_replace_all(a, "[0-9]", "")
str_replace_all(a, "[a-z A-Z]", "")

## ------------------------------------------------------------------------
a <- "The lord of the rings and harry potter are the most fascinating tales ever told in English."

y <- word(a, c(1:8))
book1 <- paste(y[1:5], collapse=" ")
str_to_title(book1)
book2 <- paste(y[7:8], collapse=" ")
str_to_title(book2)

## ------------------------------------------------------------------------
hypotenuse <- function(side1, side2){
  return(sqrt(side1^2 + side2^2))
}

## ------------------------------------------------------------------------
hypotenuse(10, 15)  
#or
hypotenuse(side1=10, side2=15)

## ------------------------------------------------------------------------
hypotenuse(10)

## ------------------------------------------------------------------------
hypotenuse <- function(side1=10, side2=15){
  return(sqrt(side1^2 + side2^2))
}

# so if one of the arguments is missing, it will still hold the default value.
hypotenuse(12)

## ------------------------------------------------------------------------
hypotenuse <- function(side1=NULL, side2=NULL){
  if(any(is.null(side1), is.null(side2))){
    stop("one of the sides is missing!")
  }
  return(sqrt(side1^2 + side2^2))
}
hypotenuse(12, 13) # This works fine. 
# But it any of the arguments is missing. it throws the error message.
hypotenuse(12)

## ------------------------------------------------------------------------
hypotenuse <- function(side1, side2){
  if(missing(side2) | missing(side1)){
    stop("one of the sides is missing!")
  }
  return(sqrt(side1^2 + side2^2))
}
hypotenuse(12)
# That stops the function if one of the arguments was missing.
# or you can use stopifnot.
hypotenuse <- function(side1, side2){
  stopifnot(!missing(side2), !missing(side1))
  return(sqrt(side1^2 + side2^2))
}
hypotenuse(12, 12)

## ------------------------------------------------------------------------
hypotenuse <- function(side1, side2, round=F, ...){
  if(missing(side2) | missing(side1)){
    stop("one of the sides is missing!")
  }
  if(round){
    return(round(sqrt(side1^2 + side2^2), ...))
  }else{
    return(sqrt(side1^2 + side2^2))
  }
}

## ------------------------------------------------------------------------
hypotenuse(side1=12, side2=15)
hypotenuse(side1=12, side2=15, round=T)  # by default it rounded to 0 digits.
# If you want to define the number of rounding digits you can pass that as well.
hypotenuse(side1=12, side2=15, round=T, digits=2)  # Great!

## ------------------------------------------------------------------------
'+'(1, 2)
'*'(2, 3)

## ------------------------------------------------------------------------
'%***%' <- function(x, y){
  return(sqrt(x^2 + y^2))
}
# Now we have a symbol function for hypotenuse.
10%***%10

## ------------------------------------------------------------------------
'%mi%' <- function(x, y){
  return(min(x, y))
}

## ------------------------------------------------------------------------
hypo <- function(side1=10, side2=15){
  if(missing(side2)){
    stop("Somethings wrong!")
  }else if(missing(side1)){
    stop("Somethings wrong!")
  }
  return(sqrt(side1^2 + side2^2))
}

hypotenuse <- function(side1, side2){
  hypo(side1, side2)
}

## ------------------------------------------------------------------------
hypotenuse(10)

## ------------------------------------------------------------------------
traceback()

## ------------------------------------------------------------------------
debugonce(hypotenuse)
hypotenuse(10)
# that shows the error happens within 'hypo' function. So lets debug that once
debugonce(hypo)
hypotenuse(10)

## ------------------------------------------------------------------------
options(error = utils::recover)
hypotenuse(10)
# You can switch off this by setting
options(error = NULL)

## ------------------------------------------------------------------------
out <- try(hypotenuse(10), silent=T) # by setting silent=TRUE, no error will be printed on the console. 
out # Now, the object out contains information about the error msg.
class(out)  # and the class of such an object will always be try-error.
out <- try(hypotenuse(10, 10), silent=T) # but in case the code did return a legit value, the output will have that
out

## ------------------------------------------------------------------------
tryCatch({hypotenuse(10)}, error=function(x){print(x)}, finally=print("Finally, print this!"))

tryCatch({hypotenuse(10, 10)}, error=function(x){print(x)}, finally=print("Finally, print this!"))

## ------------------------------------------------------------------------
output <- numeric(nrow(mtcars))  # initialise the output vector
for(i in 1:nrow(mtcars)){
  output[i] <- (mtcars[i, 1])^2 + (mtcars[i, 2])^2 + mtcars[i, 3]^2
}
output

## ------------------------------------------------------------------------
apply(mtcars, 2, FUN = ss)

## ------------------------------------------------------------------------
ss <- function(mpg, cyl, disp){
  (mpg^2) + (cyl^2) + (disp^2)
}
apply(mtcars, 1, FUN = ss)

## ------------------------------------------------------------------------
ss <- function(x){
  
}

## ------------------------------------------------------------------------
ss <- function(x){
  print(x)
}
debugonce(ss)
apply(mtcars, 1, FUN = ss)

## ------------------------------------------------------------------------
ls()
x

## ------------------------------------------------------------------------
x[1] #or
x['mpg']

## ------------------------------------------------------------------------
ss <- function(x){
  return((x['mpg']^2) + (x['cyl']^2) + (x['disp']^2) )
}

## ------------------------------------------------------------------------
ss <- function(x){
  return((x[1]^2) + (x[2]^2) + (x[3]^2) )
}
output1 <- apply(mtcars, 1, FUN = ss)
output1

## ------------------------------------------------------------------------
ss <- function(x){
  return((x[9]^2) + (x[10]^2) + (x[11]^2) )
}
output2 <- apply(mtcars, 1, FUN = ss)
output2

## ------------------------------------------------------------------------
x <- list(a1 = 1:10, a2 = 100:105, a3 = 10:20)
out_l <- lapply(x, mean)
out_l
class(out_l)

## ------------------------------------------------------------------------
out_s <- sapply(x, mean)
out_s
class(out_s)

## ------------------------------------------------------------------------
sapply(mtcars, class)

## ------------------------------------------------------------------------
vapply(mtcars[, 1:4], mean, FUN.VALUE = numeric(1))

