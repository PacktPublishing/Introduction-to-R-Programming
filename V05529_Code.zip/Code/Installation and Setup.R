# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Installation and Setup
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ------------------------------------------------------------------------
1 + 1

## ------------------------------------------------------------------------
print("Hello World")
1 + 1
5 / 2 * 3
10 %% 3  # get the remainder 
10 %/% 3  # get the quotient

source("Users/selvaprabhakaran/samplecode.R")
?print
??print 