# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Section 6 - Statistical Inference
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ------------------------------------------------------------------------
summary(mtcars$mpg)

## ------------------------------------------------------------------------
# standard deviation <dont read out, just have these comments on screen before typing code> 
sd(mtcars$mpg)

## ------------------------------------------------------------------------
# Variance
var(mtcars$mpg)

## ------------------------------------------------------------------------
# Range
range(mtcars$mpg)

## ------------------------------------------------------------------------
# Quantile
quantile(mtcars$mpg, c(.1, .25, 0.5, 0.75, 0.9))

## ------------------------------------------------------------------------
# Coefficient of Variation
sd(mtcars$mpg)/mean(mtcars$mpg)

## ------------------------------------------------------------------------
# Inter Quartile Range.
IQR(mtcars$mpg)

## ------------------------------------------------------------------------
hist(mtcars$mpg, col = "orange")

## ------------------------------------------------------------------------
table(mtcars$cyl)
hist(mtcars$cyl, col="orange")

## ------------------------------------------------------------------------
summary(cars$dist) 
sd(cars$dist)
var(cars$dist)
range(cars$dist)
quantile(cars$dist, c(.1, .25, 0.5, 0.75, 0.9))
sd(cars$dist)/mean(cars$dist)
IQR(cars$dist)

## ------------------------------------------------------------------------
hist(mtcars$mpg, freq = F)

## ------------------------------------------------------------------------
10 + (1.96 * 2 / sqrt(50))

## ------------------------------------------------------------------------
10 - (1.96 * 2 / sqrt(50))

## ------------------------------------------------------------------------
140 + ((1.96 * 10) / sqrt(30))
140 - ((1.96 * 10) / sqrt(30))

## ------------------------------------------------------------------------
cor(mtcars$mpg, mtcars$wt)
cov(mtcars$mpg, mtcars$wt)

## ------------------------------------------------------------------------
plot(mtcars$mpg, mtcars$wt)

## ------------------------------------------------------------------------
cor(mtcars$mpg, mtcars$hp)

## ------------------------------------------------------------------------
chisq.test(mtcars$cyl, mtcars$carb)
summary(table(mtcars$cyl, mtcars$carb))

## ------------------------------------------------------------------------
chisq.test(mtcars$cyl, mtcars$carb)

## ------------------------------------------------------------------------
boxplot(count ~ spray, data=InsectSprays)

## ------------------------------------------------------------------------
aov.mod <- aov(count ~ spray, data=InsectSprays)
summary(aov.mod)

## ------------------------------------------------------------------------
aov.mod <- aov(mpg ~ cyl, data=mtcars)
summary(aov.mod)

## ------------------------------------------------------------------------
set.seed(100)
x <- rnorm(20, mean=10, sd=2)
x

## ------------------------------------------------------------------------
t.test(x, mu=10)

## ------------------------------------------------------------------------
set.seed(100)
x <- rnorm(20, mean=10, sd=2)
y <- rnorm(20, mean=11, sd=2)

## ------------------------------------------------------------------------
t.test(x, y)

## ------------------------------------------------------------------------
x <- c(0.80, 0.83, 1.04, 1.45, 1.38)
y <- c(1.15, 0.88, 0.90, 0.74, 1.21)

## ------------------------------------------------------------------------
mean(x)
mean(y)

## ------------------------------------------------------------------------
wilcox.test(x, y, alternative = "g")
