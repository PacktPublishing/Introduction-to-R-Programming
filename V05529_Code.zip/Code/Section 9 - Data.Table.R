# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Section 9 - Data.Table
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ------------------------------------------------------------------------
library(data.table)
mt<- fread("https://raw.githubusercontent.com/selva86/datasets/master/mtcars.csv")
mt
class(mt)

## ------------------------------------------------------------------------
mtcars$carname <- rownames(mtcars)
df <- mtcars 
mtcars_dt <- data.table(df)
class(mtcars_dt)
mtcars_dt

## ------------------------------------------------------------------------
setDT(df)
class(df)
df

## ------------------------------------------------------------------------
setDF(df)
class(df)
df

## ------------------------------------------------------------------------
mtcars[mtcars$cyl == 6 & mtcars$gear == 4, ]

## ------------------------------------------------------------------------
mtcars_dt[cyl==6 & gear==4, ]

## ------------------------------------------------------------------------
mtcars[, 1]

## ------------------------------------------------------------------------
mtcars_dt[, 1]

## ------------------------------------------------------------------------
mtcars_dt[, 1, with=F]

## ------------------------------------------------------------------------
mtcars_dt[, mpg]

## ------------------------------------------------------------------------
myvar <- "mpg"
mtcars_dt[, myvar, with=F]

## ------------------------------------------------------------------------
mtcars_dt[, list(mpg, cyl, gear)]

## ------------------------------------------------------------------------
mtcars_dt[, .(mpg, cyl, gear)]

## ------------------------------------------------------------------------
aq_dt <- data.table(airquality)
aq_dt[!is.na(Ozone), .(Solar.R, Wind, Temp)]

## ------------------------------------------------------------------------
library(data.table)
mtcars$carname <- rownames(mtcars)
mtcars_dt <- data.table(mtcars)

mtcars_dt$cyl_gear <- mtcars_dt$cyl + mtcars_dt$gear
mtcars_dt

## ------------------------------------------------------------------------
mtcars_dt[, cyl_gear2 := cyl + gear]
mtcars_dt

## ------------------------------------------------------------------------
mtcars_dt[,  `:=`(cyl_gear3 = cyl * gear,
                  cyl_gear4 = cyl - gear)]
mtcars_dt

## ------------------------------------------------------------------------
mtcars_dt[,  .(cyl_gear3 = cyl * gear,
               cyl_gear4 = cyl - gear)]

## ------------------------------------------------------------------------
myvar <- c('var1')

## ------------------------------------------------------------------------
mtcars_dt[, myvar:=1]
mtcars_dt

## ------------------------------------------------------------------------
mtcars_dt[, c(myvar):=1]
mtcars_dt

## ------------------------------------------------------------------------
mtcars_dt[, (myvar):=2]
mtcars_dt

## ------------------------------------------------------------------------
mtcars_dt[, c("cyl_gear2", "cyl_gear", "cyl_gear3", "cyl_gear4", "myvar", "var1") := NULL]

## ------------------------------------------------------------------------
mtcars_dt[, scaled_mpg := round(mpg/mean(mpg), 2)]

## ------------------------------------------------------------------------
library(data.table)
mtcars$carname <- rownames(mtcars)
mtcars_dt <- data.table(mtcars)

mtcars_dt[, .(mean_mileage=mean(mpg)), by=cyl]

## ------------------------------------------------------------------------
mtcars_dt[, .(mean_mileage=mean(mpg)), by=.(cyl, gear)]

## ------------------------------------------------------------------------
mtcars_dt[, .(first_mileage=mpg[1]), by=cyl]

## ------------------------------------------------------------------------
mtcars_dt[, .(second_mileage=mpg[2]), by=cyl]

## ------------------------------------------------------------------------
mtcars_dt[, .(last_mileage=mpg[length(mpg)]), by=cyl]

## ------------------------------------------------------------------------
mtcars_dt[, .(last_mileage=mpg[.N]), by=cyl]

## ------------------------------------------------------------------------
mtcars_dt[, .N, by=cyl]

## ------------------------------------------------------------------------
mtcars_dt[, .I]

## ------------------------------------------------------------------------
mtcars_dt[cyl==6, .I]

## ------------------------------------------------------------------------
mtcars_dt[, .I[cyl==6]]

## ------------------------------------------------------------------------
mtcars_dt[, which(cyl==6)]

## ------------------------------------------------------------------------
mtcars_dt[, .(.N, mileage=mean(mpg) %>% round(2)), by=gear]

## ------------------------------------------------------------------------
library(data.table)
mtcars$carname <- rownames(mtcars)
mtcars_dt <- data.table(mtcars)
dt1 <- mtcars_dt[, .(mean_mpg=mean(mpg),
                     mean_disp=mean(disp),
                     mean_wt=mean(wt),
                     mean_qsec=mean(qsec)), by=cyl]
output <- dt1[order(cyl), ]
output

## ------------------------------------------------------------------------
output <- mtcars_dt[, .(mean_mpg=mean(mpg),
                        mean_disp=mean(disp),
                        mean_wt=mean(wt),
                        mean_qsec=mean(qsec)), by=cyl][order(cyl), ]

## ------------------------------------------------------------------------
mtcars_dt[, .SD, by=cyl]

## ------------------------------------------------------------------------
output <- mtcars_dt[, lapply(.SD[, 1:10, with=F], mean), by=cyl]
output

## ------------------------------------------------------------------------
output <- mtcars_dt[, lapply(.SD, mean), by=cyl, .SDcols=c("mpg", "disp", "hp", "drat", "wt", "qsec")]
output

## ------------------------------------------------------------------------
set.seed(100)
rand <- sample(1:10, 100000, replace=T)
mymat <- matrix(rand, ncol=5)

# or just run this
source("https://goo.gl/jMbtpU")

## ------------------------------------------------------------------------
library(data.table)
dt <- data.table(mymat)
ss <- function(x){(x['V1']^2) + (x['V2']^2) + (x['V3']^2) + (x['V4']^2) + (x['V5']^2)}
dt[, ss:=apply(.SD, 1, ss)]

## ------------------------------------------------------------------------
dt$ss <- apply(dt, 1, ss)

## ------------------------------------------------------------------------
dt$ss <- (dt$V1^2) + (dt$V2^2) + (dt$V3^2) + (dt$V4^2) + (dt$V5^2)

## ------------------------------------------------------------------------
library(data.table)
mtcars$carname <- rownames(mtcars)

## ------------------------------------------------------------------------
mtcars_dt <- data.table(mtcars, key="carname")

## ------------------------------------------------------------------------
mtcars_dt <- data.table(mtcars)
setkey(mtcars_dt, carname)

## ------------------------------------------------------------------------
mtcars_dt

## ------------------------------------------------------------------------
key(mtcars_dt)

## ------------------------------------------------------------------------
mtcars_dt["Merc 230"]
mtcars_dt["Valiant"]

## ------------------------------------------------------------------------
dt1 <- mtcars_dt[1:10,.(carname, mpg, cyl)]
dt2 <- mtcars_dt[6:15, .(carname, gear)]
dt1
dt2

## ------------------------------------------------------------------------
dt1[dt2]

## ------------------------------------------------------------------------
dt2[dt1]

## ------------------------------------------------------------------------
dt2[dt1, nomatch=0L]

## ------------------------------------------------------------------------
dt1[dt2[.(union(dt2$carname, dt1$carname))]]

## ------------------------------------------------------------------------
merge(dt1, dt2, all = T)  # full join
merge(dt1, dt2, all = F)  # inner join
merge(dt1, dt2, all.x = T)  # left join
merge(dt1, dt2, all.y = T)  # right join

## ------------------------------------------------------------------------
setkey(mtcars_dt, cyl, gear)
key(mtcars_dt)

## ------------------------------------------------------------------------
mtcars_dt[c(8, 3)] # this is incorrect as of version 1.9.6. So always enclose numeric keys in a dot.
mtcars_dt[.(8, 3)]
mtcars_dt[J(8, 3)]

## ------------------------------------------------------------------------
setkey(mtcars_dt, NULL)
mtcars_dt

## ------------------------------------------------------------------------
output <- mtcars_dt[, .(mean_mpg=mean(mpg),
                        mean_disp=mean(disp),
                        mean_wt=mean(wt),
                        mean_qsec=mean(qsec)), by=cyl][order(cyl), ]
output

output <- mtcars_dt[, .(mean_mpg=mean(mpg),
                        mean_disp=mean(disp),
                        mean_wt=mean(wt),
                        mean_qsec=mean(qsec)), keyby=cyl]
output
key(output)

## ------------------------------------------------------------------------
M <- matrix(1, nrow=100000, ncol=2)
dt <- as.data.table(M)
dt

## ------------------------------------------------------------------------
system.time({
  for(i in 1:nrow(dt)){
    dt[i, V1:=0]
  }  
})
dt[1:5, 1:5, with=F]

## ------------------------------------------------------------------------
dt <- as.data.table(M)
system.time({
  for(i in 1:nrow(dt)){
    set(dt, i, 1L, 0)
  }  
})
#   user  system elapsed 
#  0.192   0.000   0.192 
dt[1:5, 1:5, with=F]

## ------------------------------------------------------------------------
M <- matrix(1, nrow=10000, ncol=10000)
df <- as.data.frame(M)
df[1:5, 1:5]

## ------------------------------------------------------------------------
for(i in 1:nrow(df)){
  set(df, i, i, i)
}
df[1:5, 1:5]