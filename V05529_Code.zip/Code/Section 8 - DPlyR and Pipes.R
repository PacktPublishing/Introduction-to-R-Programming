# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Section 8 - DPlyR and Pipes
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ------------------------------------------------------------------------
df1 <- mtcars[mtcars$hp > 150, ]
df2 <- aggregate( . ~ cyl, data=df1, FUN=mean)
df3 <- round(df2, 2)
df3$kpl <- df3$mpg*0.42

## ------------------------------------------------------------------------
df_1 <- round(aggregate( . ~ cyl, data=mtcars[mtcars$hp > 150, ], FUN=mean), 2)
df_1$kpl <- df_1$mpg*0.42

## ------------------------------------------------------------------------
output <- mtcars %>% subset(hp > 150) %>%
  aggregate(. ~ cyl, data = ., FUN = mean) %>% round(2) %>% 
  transform(kpl = mpg %>% multiply_by(0.42))

## ------------------------------------------------------------------------
2.2452323 %>% round(3)

## ------------------------------------------------------------------------
rnorm(10) %T>% plot(main="rnorm") %>% sum

## ------------------------------------------------------------------------
mtcars$mpg %<>% sqrt

## ------------------------------------------------------------------------
mtcars %$% cor(mpg, cyl)

## ------------------------------------------------------------------------
mtcars %>% subset(cyl==6) %$% cor(mpg, wt)

## ------------------------------------------------------------------------
library(hflights)
library(dplyr)
hf_tbl <- as.tbl(hflights)
hf_tbl

## ------------------------------------------------------------------------
dplyr::glimpse(hf_tbl)

## ------------------------------------------------------------------------
filter(hf_tbl, Month==1, Year==2011)

## ------------------------------------------------------------------------
filter(hf_tbl, (Month==1 & Year==2011))

## ------------------------------------------------------------------------
slice(hf_tbl, 2:6)
# This is effectively same as. 
hf_tbl[2:6, ]

## ------------------------------------------------------------------------
hf_tbl %>% filter(Month==1) %>% slice(1:5)

# This is same as using the square bracket as a function by enclosing it within a pair of quotes.
hf_tbl %>% filter(Month==1) %>% `[`(1:5, )

## ------------------------------------------------------------------------
dplyr::select(hf_tbl, Year, DayOfWeek)
dplyr::select(hf_tbl, Year:DayOfWeek) # if you want to select all variables between them.
select(hf_tbl, 1, 2)
select(hf_tbl, c(1, 2))

## ------------------------------------------------------------------------
select(hf_tbl, contains("Time"))
select(hf_tbl, starts_with("Day"))
select(hf_tbl, ends_with("Time"))

## ------------------------------------------------------------------------
hf_tbl_1 <- rename(hf_tbl, mth=Month)
hf_tbl_1

## ------------------------------------------------------------------------
ht_tbl_2 <- mutate(hf_tbl, yearmonth=paste0(Year, Month) %>% as.numeric)
glimpse(ht_tbl_2)

## ------------------------------------------------------------------------
ht_tbl_3 <- transmute(hf_tbl, yearmonth=paste0(Year, Month) %>% as.numeric)
ht_tbl_3

## ------------------------------------------------------------------------
arrange(hf_tbl, Year, Month)

## ------------------------------------------------------------------------
arrange(hf_tbl, Year, desc(Month))

## ------------------------------------------------------------------------
library(dplyr)
data(mtcars)
mtcars_tbl <- mtcars %>% 
  mutate(make=rownames(mtcars)) %>% 
  as.tbl() %>% 
  mutate(kpl=0.425*mpg, kpl_int=round(kpl)) %>% 
  arrange(kpl) %>% filter(vs==1)
mtcars_tbl

## ------------------------------------------------------------------------
library(dplyr)
library(hflights)
hf_tbl <- as.tbl(hflights)
hf_tbl_gp <- group_by(hf_tbl, UniqueCarrier)
hf_tbl_gp  # the grouped tbl will appear the same. But it will have a new grouped_df class.
class(hf_tbl_gp)  # now its a grouped_df

## ------------------------------------------------------------------------
summarise(hf_tbl_gp, mean_dist=mean(Distance))

## ------------------------------------------------------------------------
unique_carrier_agg <- hflights %>% group_by(UniqueCarrier) %>% summarize(delay=mean(DepDelay, na.rm=T),
                                                                         num_obs=n(),  # n() gets the number of observations in the grouped variable.
                                                                         num_distinct_obs=n_distinct(DepDelay), # n_distinct gets the number of distinct observations in the specified variable.
                                                                         first_obs=first(DepDelay), # first for first observation
                                                                         second_obs=nth(DepDelay, 2),  # nth for nth observation from start 
                                                                         last_obs=last(DepDelay))  # and last for the last observation.

## ------------------------------------------------------------------------
hf_tbl_gp <- ungroup(hf_tbl_gp)
hf_tbl_gp  # As expected, the groups information does not show now.

## ------------------------------------------------------------------------
origin_agg <- hflights %>% group_by(Origin) %>% summarize(delay=mean(DepDelay, na.rm=T),
                                                          num_obs=n(),  
                                                          num_distinct_obs=n_distinct(DepDelay),
                                                          first_obs=first(DepDelay), 
                                                          second_obs=nth(DepDelay, 2), 
                                                          last_obs=last(DepDelay))

## ------------------------------------------------------------------------
library(dplyr)
mtcars$carname <- mtcars %>% rownames
mtcars_tbl <- mtcars %>% as.tbl
mtcars_tbl_1 <- mtcars_tbl %>% select(carname, mpg:drat)
mtcars_tbl_2 <- mtcars_tbl %>% select(carname, wt:am) %>% sample_frac(.4)
mtcars_tbl_3 <- rename(mtcars_tbl_2, car=carname)  

## ------------------------------------------------------------------------
mtcars_tbl_1 %>% left_join(mtcars_tbl_2)

## ------------------------------------------------------------------------
mtcars_tbl_1 %>% left_join(mtcars_tbl_3, c("carname"="car"))

## ------------------------------------------------------------------------
mtcars_tbl_1 %>% right_join(mtcars_tbl_2)
mtcars_tbl_1 %>% inner_join(mtcars_tbl_2)
mtcars_tbl_1 %>% full_join(mtcars_tbl_2)

## ------------------------------------------------------------------------
library(dplyr)
flights <- as.tbl(hflights)
my_db <- src_sqlite("my_db.sqlite3", create = T)
my_db

## ------------------------------------------------------------------------
copy_to(my_db, flights, temporary = FALSE, indexes = list(c("Year", "Month", "DayofMonth"), "UniqueCarrier", "TailNum"))
my_db

## ------------------------------------------------------------------------
flights_out <- tbl(my_db, "flights")

## ------------------------------------------------------------------------
flights_out <- tbl(my_db, sql("SELECT * FROM flights"))
flights_out
class(flights_out) 

## ------------------------------------------------------------------------
flights_out %>% group_by(UniqueCarrier) %>% summarise(speed=sum(Distance)/sum(AirTime))

myData <- flights_out %>% filter(UniqueCarrier=="AA") %>% mutate(TaxiTime=TaxiIn + TaxiOut) %>% select(Year, Month, DayofMonth, DayOfWeek, DepTime, UniqueCarrier, TaxiTime)

## ------------------------------------------------------------------------
out <- collect(myData)
out

## ------------------------------------------------------------------------
myData$query