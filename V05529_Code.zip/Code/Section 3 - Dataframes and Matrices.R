# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Section 3 - Dataframes and Matrices
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ------------------------------------------------------------------------
set.seed(100)
a <- c(1:17, NA)
b <- c("a", "b", "c", "d", NA, "f", "a", "b", "c", "d", NA, "f", "a", "b", "c", "d", NA, "f")
c <- factor(sample(c("red", "blue", "green"), 18, replace=T))
a
b
c

## ------------------------------------------------------------------------
df1 <- data.frame(v1=a, v2=b, v3=c)
df1
class(df1)

## ------------------------------------------------------------------------
dim(df1) 

## ------------------------------------------------------------------------
nrow(df1)  # 

## ------------------------------------------------------------------------
ncol(df1)  # 

## ------------------------------------------------------------------------
rownames(df1)
colnames(df1)
colnames(df1) <- c("A", "B", "C")
df1

## ------------------------------------------------------------------------
head(df1)  # 

## ------------------------------------------------------------------------
head(df1, 3)  # 

## ------------------------------------------------------------------------
tail(df1)

## ------------------------------------------------------------------------
View(df1) # 

## ------------------------------------------------------------------------
mat <- t(df1)
mat
class(mat)

## ------------------------------------------------------------------------
summary(df1)

## ------------------------------------------------------------------------
str(df1)

## ------------------------------------------------------------------------
options(stringsAsFactors=F)

## ------------------------------------------------------------------------
df1 <- data.frame(v1=a, v2=b, v3=c)
str(df1)

## ------------------------------------------------------------------------
options(stringsAsFactors=T)

## ------------------------------------------------------------------------
df1 <- data.frame(v1=a, v2=b, v3=c)
df1
str(df1)  

## ------------------------------------------------------------------------
df1$v2 <- as.character(df1$v2) # or
df1$v2 <- as.character(df1[, 2]) #or
df1$v2 <- as.character(df1[, "v2"])
str(df1)

## ------------------------------------------------------------------------
df1[, c(1, 2)] # or
df1[, c("v1", "v2")]

## ------------------------------------------------------------------------
df1[, 1, 2]  # 

## ------------------------------------------------------------------------
df1[c(5:10), c(1,2)]  # 

## ------------------------------------------------------------------------
df1[which(df1$v1 > 5), c(1, 2)]

## ------------------------------------------------------------------------
index <- which(df1$v1 > 5)  # 
index

## ------------------------------------------------------------------------
df1[index, c(1, 2)]

## ------------------------------------------------------------------------
df1[df1$v1 > 5, c(1, 2)]

## ------------------------------------------------------------------------
subset(df1, select=c(1, 2), subset=v1>5)

## ------------------------------------------------------------------------
df2 <- na.omit(df1)
df2

## ------------------------------------------------------------------------
index <- !is.na(df1$v1) 
index
df1[index, ]  # 

## ------------------------------------------------------------------------
df1[!is.na(df1$v1) , ]

## ------------------------------------------------------------------------
a <- c(1:17, NA)
b <- c("a", "b", "c", "d", NA, "f", "a", "b", "c", "d", NA, "f", "a", "b", "c", "d", NA, "f")
c <- factor(sample(c("red", "blue", "green"), 18, replace=T))
df1 <- data.frame(a, b, c, stringsAsFactors = F)

# Answer: 
index <- df1$c %in% c("green", "blue")
df2 <- df1[index, ]
na.omit(df2)

## ------------------------------------------------------------------------
library(help="datasets") # and you can see the description of this package that displays all the dataset names.

## ------------------------------------------------------------------------
write.csv(mtcars, "mtcars.csv", row.names = F)

## ------------------------------------------------------------------------
getwd()  

## ------------------------------------------------------------------------
setwd("/Users/selvaprabhakaran/Documents/Packt/r programming course/")

## ------------------------------------------------------------------------
path <- file.path(getwd(), "data/mtcars.csv")
write.csv(mtcars, path, row.names = F)

## ------------------------------------------------------------------------
saveRDS(mtcars, file.path(getwd(), "mtcars.RDS"), compress = T)
x <- readRDS(file.path(getwd(), "mtcars.RDS"))

## ------------------------------------------------------------------------
fpath <- file.path(getwd(), "mtcars.Rdata")
save(mtcars, cars, file=fpath)
load(fpath)

## ------------------------------------------------------------------------
fpath <- file.path(getwd(), "all_obj.Rdata")
save.image(fpath)
load(fpath)

## ------------------------------------------------------------------------
mydata <- read.table(path, sep=",")
mydata

## ------------------------------------------------------------------------
mydata <- read.csv(path)

## ------------------------------------------------------------------------
library(readxl)
read_excel("filepath.xlsx", sheet=1)
# or if you think the sheet number could change, you can enter the sheetname.
excel_data <- read_excel("filepath.xlsx", sheet="sheet1")

## ------------------------------------------------------------------------
sasdata <- read_sas("http://crn.cancer.gov/resources/ctcodes-procedures.sas7bdat")
# For SPSS files you can use the read_sav or read_por
spss_dat <- read_sav('filepath.sav')
spss_dat1 <- read_por('filepath.por')
# Likewise, for stata files, use the read_dta function
stata_dat <- read_dta("filepath.dta")

## ------------------------------------------------------------------------
object.size(mtcars)

## ------------------------------------------------------------------------
mtcars_mat <- as.matrix(mtcars)
object.size(mtcars_mat)

## ------------------------------------------------------------------------
m1 <- matrix(1:100, nrow = 10)
m1

## ------------------------------------------------------------------------
m1 <- matrix(1:100, nrow = 10, byrow = T)
m1
dim(m1)

## ------------------------------------------------------------------------
m1[, c(1, 2)]
m1[1:5, c(1, 2)]

## ------------------------------------------------------------------------
diag(m1)

## ------------------------------------------------------------------------
rowSums(m1)
rowMeans(m1)
colSums(m1)
colMeans(m1)
cumsum(m1)

## ------------------------------------------------------------------------
table(mtcars$cyl)
# And if you want to create counts against 2 vectors, 
# specify the vector that goes in row first follow by the column vector
tb <- table(mtcars$cyl, mtcars$vs)
tb
class(tb)

## ------------------------------------------------------------------------
as.data.frame(tb)

## ------------------------------------------------------------------------
tb_m <- as.matrix(tb)
class(tb_m)

## ------------------------------------------------------------------------
tb_df <- as.data.frame.matrix(tb)
class(tb_df)

## ------------------------------------------------------------------------
tb_df[, 1]

## ------------------------------------------------------------------------
tb1 <- table(mtcars$cyl, mtcars$gear)
tb2 <- as.data.frame.matrix(tb1)
tb2
tb2[rownames(tb2) == "6", "4"]

## ------------------------------------------------------------------------
set.seed(100)
df1 = data.frame(FruitId = c(1:10),
                 Subject = sample(c("Apple", "Banana", "Mango"), 10, replace=T))

df2 = data.frame(FruitNum = c(2, 4, 6, 12),
                 Cuisine = sample(c("Chinese", "Italian", "Mexican"), 4, replace=T))
df1
df2

## ------------------------------------------------------------------------
merge(df1, df2, by.x="FruitId",by.y="FruitNum") # by.x refers to the column name in df1 and by.y refers to the column name in df2.

## ------------------------------------------------------------------------
merge(df1, df2, by.x="FruitId",by.y="FruitNum", all=T) # by settin all=T, we can retain all the observations from both dataframes.
# And if you want to retain only the observations in df1, then do:
merge(df1, df2, by.x="FruitId",by.y="FruitNum", all.x=T)
# Else, if you want to retain observations from right dataframe df2, then:
merge(df1, df2, by.x="FruitId",by.y="FruitNum", all.y=T)

## ------------------------------------------------------------------------
head(ChickWeight)
# This dataset shows the weight of chicks that were given different diets at various points in time.

## ------------------------------------------------------------------------
aggregate(weight ~ Diet, data=ChickWeight, FUN=mean)
# You can read it as, Get the weight as a function of Diet from the dataset ChickWeight. 
# By setting the FUN to `mean`, you get the mean weights for each of the diets.

# Suppose if you want the sum instead of mean, you can write:
aggregate(weight ~ Diet, data=ChickWeight, FUN=sum)

# Of if you are interested in how many chicks were given each diet, use the length function instead.
aggregate(weight ~ Diet, data=ChickWeight, FUN=length)

# Also, it is possible to aggregate by a combination of variables
aggregate(weight ~ Chick + Diet, data=ChickWeight, FUN=mean)

## ------------------------------------------------------------------------
aggregate(weight ~ Time, data=ChickWeight, FUN=mean)

## ------------------------------------------------------------------------
# install.package("reshape2", repos="http://cran.rstudio.com")
library(reshape2)
library(ggplot2)


## ------------------------------------------------------------------------
head(economics)
melted <- melt(economics, id="date")
# This brings the dataset to the level of "date" variable. All other features are stacked 
# under the 'value' variable and the column called 'variable' shows what feature the 
# respective values belong.
head(melted)

## ------------------------------------------------------------------------
head(french_fries)

## ------------------------------------------------------------------------

a <- dcast(french_fries, treatment ~ subject, value.var="potato", fun.aggregate=mean) 
a
# The dcast takes in the dataframe as the first argument. Then a formula to define what goes 
# in the rows and columns of the output, then the 'value.var' argument takes which variable 
# to use to fill up the table's values and finally the function by which 'value.var' has to be 
# aggregated.
# This is a very useful function often used in exploratory data analysis.

## ------------------------------------------------------------------------
a <- dcast(french_fries, treatment ~ subject, value.var="rancid", fun.aggregate=median) 
a

