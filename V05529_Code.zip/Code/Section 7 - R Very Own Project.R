# Author         : Selva Prabhakaran
# Course Name    : Introduction to R Programming Course
# Section        : Section 7 - R Very Own Project
# Compiled On    : 2nd July 2016.
# Course URL     : https://www.packtpub.com/application-development/introduction-r-programming-video
# Info 
# - Author website : http://r-statistics.co and http://rstatistics.net
# - Follow         : www.twitter.com/r_programming
# - Youtube        : http://youtube.com/user/thelearnr 
# - Email          : selva86@gmail.com

## ------------------------------------------------------------------------
mtcars

## ------------------------------------------------------------------------
install.packages("hflights", repos = "http://cran.rstudio.com")
data("hflights", package="hflights")

#or just run
hflights <- read.csv("https://raw.githubusercontent.com/selva86/datasets/master/hflights.csv")
head(hflights)

## ------------------------------------------------------------------------
hflights$delayed <- ifelse(hflights$DepDelay > 0, 1, 0)
carrier_delay_count <- table(hflights$UniqueCarrier, hflights$delayed)
carrier_delay_count <- as.data.frame.matrix(carrier_delay_count)
class(carrier_delay_count)
carrier_delay_count

# This gives us the number of flights that we delayed and those that were on-time. Now lets find out the percentage delayed.

# If you have an invalid column name like we have here, you can access it by enclosing the column name within backticks.
carrier_delay_count$perc_delayed <- carrier_delay_count$`1` / as.numeric(carrier_delay_count$`0` + carrier_delay_count$`1`)

# In absolute terms, the carrier that had most late departures is
rownames(carrier_delay_count)[which.max(carrier_delay_count$`1`)]
# CO

# While, the carrier that had most late departures in percentage is
rownames(carrier_delay_count)[which.max(carrier_delay_count$perc_delayed)]
# WN

## ------------------------------------------------------------------------
library(lubridate)
hflights$Date <- paste(hflights$Year, hflights$Month, hflights$DayofMonth, sep="-")
hflights$Date <- ymd(hflights$Date)
departures <- (table(hflights$Date))
departures[departures == max(departures)]

## ------------------------------------------------------------------------
carrier_tailnum <- (as.data.frame.matrix(table(hflights$UniqueCarrier, hflights$TailNum)))
# We want to count the unique tail nums, so if the value is greater than 0, I will make it 1 so we count that tailnum only once.

fleet_count <- as.data.frame(ifelse(carrier_tailnum > 0, 1, 0))

# now, rowsums should give the number of tail nums for the uniquecarriers.
rowSums(fleet_count)
# The carrier WN with a fleet size of 567 seems to have the largest fleet size operating out of IAH and HOU airports.

## ------------------------------------------------------------------------
fn1 <- aggregate(cbind(ActualElapsedTime, AirTime, ArrDelay, DepDelay, Distance, TaxiIn, TaxiOut) ~ FlightNum, data=hflights, FUN = function(x)round(mean(x, na.rm=T), 2))

# For computing number of flights, we can choose any arbitrary variable, because, we just need to count the Flightnums.
fn2 <- aggregate(Year ~ FlightNum, data=hflights, FUN=length)
colnames(fn2) <- c("FlightNum", "NumFlights")

# For cancelled flights, you can choose only the those rows where Cancelled variable equals 1.
# Method 1
fn3 <- aggregate(Cancelled ~ FlightNum, data=hflights[hflights$Cancelled==1, ], FUN=length)


# Finally lets Merge
fn1 <- merge(fn1, fn2, by="FlightNum", all.x=T)
fn1 <- merge(fn1, fn3, by="FlightNum", all.x=T)

# and replace the missing values with zero.
fn1$Cancelled[is.na(fn1$Cancelled)] <- 0

# Percentage Cancelled
fn1$perc_cancelled <- round(fn1$Cancelled / fn1$NumFlights, 4) *100 

fn1[order(-fn1$perc_cancelled), ]

## ------------------------------------------------------------------------
library(reshape2)

carrier_month_delays <- dcast(UniqueCarrier ~ Month, data=hflights, value.var="DepDelay", fun.aggregate=function(x)round(mean(x, na.rm=T), 2))

# Lets find out which carriers departed on time and which had long delays?
carrier_meandelay <- rowMeans(carrier_month_delays[, -1], na.rm=T)

# As you can notice, certain carriers have long delays while some take off on time. Lets get their names.
carrier_month_delays$UniqueCarrier[which(carrier_meandelay < 2)]
carrier_month_delays$UniqueCarrier[which(carrier_meandelay > 10)]

# Lets compute the average monthly departure delay time
colMeans(carrier_month_delays[, -1], na.rm=T)

# It appears as if there are some seasonal influences on the late departures. The months of may, june and july has the longest delays while the months of september and october have the shortest delays.

## ------------------------------------------------------------------------
hist(hflights$Month)
barplot(table(hflights$Month), main="Monthly Departures", ylab="Number of Deparures", xlab="Month")

## ------------------------------------------------------------------------
par(mar=c(4, 4, 3, 1 ))
origin_departures <- table(hflights$Origin, hflights$Month)

# now convert it to a data.frame
origin_departures <- as.data.frame.matrix(origin_departures)
origin_departures

# First lets make the line chart for "HOU"
plot(as.numeric(origin_departures[1, ]), type="b", ylim = c(0, 20000), main="Total Number of Departures", ylab="Number of Departures", xlab="Month", col="blue", lwd=2)

# Lets add more information by adding the actual values above the points as text.
text(x=1:12, y=as.numeric(origin_departures[1, ]+1000), labels=as.numeric(origin_departures[1, ]), cex=0.5)

# Now lets draw the other "Origin". This time, we dont want to use the plot function, because that would erase this and make a new plot. So, instead, lets use the 'lines' function.
lines(as.numeric(origin_departures[2, ]), type="b", ylim = c(0, 20000), main="Total Number of Departures", ylab="Number of Departures", xlab="Month", col="orange", lwd=2)

# And draw the text as done before.
text(x=1:12, y=as.numeric(origin_departures[2, ]+1000), labels=as.numeric(origin_departures[2, ]), cex=0.5)

# Nice!

## ------------------------------------------------------------------------
hf1 <- hflights[hflights$DepDelay > 0, ]
boxout <- boxplot(DepDelay ~ UniqueCarrier, data=hf1, ylim=c(0,100), main="Departure Delays for Unique Carriers")

## ------------------------------------------------------------------------
# These events are captured within the `out` variable in boxout
boxout$out

# How many such events are present in each uniquecarrier?
long_delays <- boxout$n
long_delays
# So, the unique carriers CO, OO, WN and XE have the most number of long delays. But this may not be the only metric we should look at to judge a carriers' performance. Because, some carriers handle a lot more traffic than others. So we should actually look at the proportion of long delays.

total_departures <- as.numeric(table(hflights$UniqueCarrier))
round(long_delays/total_departures, 2)

# The proportion of long delays is too high for: WN, UA, OO and CO.

## ------------------------------------------------------------------------
# If you havent installed the car package, then install it
install.packages("car", repos = "http:/cran.rstudio.com")

data(Prestige, package = "car")
head(Prestige)

# or run
Prestige <- read.csv("https://github.com/selva86/datasets/raw/master/Prestige.csv")

## ------------------------------------------------------------------------
cor.test(Prestige$education, Prestige$prestige)
cor.test(Prestige$income, Prestige$prestige)
cor.test(Prestige$women, Prestige$prestige)

## ------------------------------------------------------------------------
boxplot(prestige ~ type, data=Prestige)
# from the boxplot, we can infer that the 'prof' type has a higher prestige score. So lets confirm that using anova.
aovmod <- aov(prestige ~ type, data=Prestige)
summary(aovmod)
# With a high F-ratio and p-value less than the significance level of 0.05, we can reject the null hypothesis, and conclude that the relationship between type and prestige score is statistically significant.